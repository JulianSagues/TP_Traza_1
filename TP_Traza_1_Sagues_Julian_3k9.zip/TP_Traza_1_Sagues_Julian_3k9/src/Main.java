import java.time.LocalTime;

public class Main {
    public static void main(String[] args) {
        /**creamos el pais**/
        Pais argentina = new Pais("Argentina");

        /**creamos  las provincias**/
        Provincia buenosAires = new Provincia("Buenos Aires",argentina);
        Provincia cordoba = new Provincia("Cordoba", argentina);

        /**localidades de bs**/
        Localidad caba = new Localidad("CABA", buenosAires);
        Localidad laPlata = new Localidad("La Plata", buenosAires);

        /**localidesd de cordoba**/
        Localidad cordobaCap = new Localidad("Cordoba Capital", cordoba);
        Localidad villaCarlosPaz = new Localidad("Villa CarlosPaz", cordoba);

        /**domicilios de bs**/
        Domicilio domCaba = new Domicilio("Av. Corrientes", 465, 5578, caba);
        Domicilio domLaPlata = new Domicilio("Av. La Plata", 465, 5578, laPlata);

        /**domicilios de corodoba**/
        Domicilio domCordobaCap = new Domicilio("Av. Colón", 1000, 675 ,cordobaCap);
        Domicilio domVcp        = new Domicilio("Av. Libertad", 500, 897 ,villaCarlosPaz);

        /**sucursales**/
        Sucursal suc1 = new Sucursal("Sucursal1", LocalTime.of(9,0), LocalTime.of(13,0),true,domCaba);
        Sucursal suc2 = new Sucursal("Sucursal2",LocalTime.of(9,0),LocalTime.of(15,0),false,domLaPlata);
        Sucursal suc3 = new Sucursal("Sucursal3",LocalTime.of(9,0),LocalTime.of(16,0),true,domCordobaCap);
        Sucursal suc4 = new Sucursal("Sucursal4",LocalTime.of(9,0),LocalTime.of(12,0),true, domVcp);

        /**empresas**/
        Empresa emp1 = new Empresa();
        emp1.setNombre("Empresa1");
        emp1.setRazonSocial("S.A.");
        emp1.setCuit(1354667564);
        emp1.setLogo("logo1.png");
        emp1.agregarSucursal(suc1);
        emp1.agregarSucursal(suc2);

        Empresa emp2 = new Empresa();
        emp2.setNombre("Empresa2");
        emp2.setRazonSocial("S.R.L.");
        emp2.setCuit(1235845123);
        emp2.setLogo("logo2.png");
        emp2.agregarSucursal(suc3);
        emp2.agregarSucursal(suc4);

        /**agregamos las empresas**/
        Empresa.agregarEmpresa(emp1);
        Empresa.agregarEmpresa(emp2);

        System.out.println("----------------------------------------------------------------------");
        System.out.println("== Mostrar todas las empresas ==");
        Empresa.mostrarEmpresa();
        System.out.println("----------------------------------------------------------------------");
        System.out.println("== Buscar empresa por ID (CUIT) ==");
        System.out.println(Empresa.buscarPorId(1235845123));
        System.out.println("----------------------------------------------------------------------");
        System.out.println("== Buscar empresa por nombre ==");
        System.out.println(Empresa.buscarPorNombre("empresa2"));
        System.out.println("----------------------------------------------------------------------");
        System.out.println("== Actualizar CUIT por ID ==");
        boolean okUpdate = Empresa.actualizarCuit(1235845123, 678457854);
        System.out.println("Actualización OK? " + okUpdate);
        Empresa.mostrarEmpresa();
        System.out.println("----------------------------------------------------------------------");
        System.out.println("== Eliminar empresa por ID ==");
        boolean okDelete = Empresa.eliminarEmpresaPorCuit(678457854);
        System.out.println("Eliminación OK? " + okDelete);
        Empresa.mostrarEmpresa();
        System.out.println("----------------------------------------------------------------------");
    }
}