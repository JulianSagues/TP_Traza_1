package Traza1;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.*;

@Getter
@Setter
@ToString(onlyExplicitlyIncluded = true)
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
public class Empresa {

    @ToString.Include private String nombre;

    private String razonSocial;

    @EqualsAndHashCode.Include
    @ToString.Include
    private Integer cuit;

    private String logo;

    /**Relacion a sucursal con un HashSer**/
    private final Set<Sucursal> sucursales = new HashSet<>();

    /**Metodos del HashSet**/
    public boolean agregarSucursal(Sucursal sucursal) {
        return sucursales.add(sucursal);
    }

    public boolean eliminarSucursal(Sucursal sucursal) {
        return sucursales.remove(sucursal);
    }

    public Set<Sucursal> getSucursales() {
        return Collections.unmodifiableSet(sucursales);
    }

    /**Gestion de empresas**/
    private static final Set<Empresa> empresas = new HashSet<>();

    public static boolean agregarEmpresa(Empresa empresa) {
        return empresas.add(empresa);
    }

    public static boolean eliminarEmpresaPorCuit(Integer cuit) {
        return empresas.removeIf(e -> e.getCuit().equals(cuit));
    }

    public static Empresa buscarPorId(Integer cuit) {
        return empresas.stream()
                .filter(e -> e.getCuit().equals(cuit))
                .findFirst()
                .orElse(null);
    }

    public static Empresa buscarPorNombre(String nombre) {
        return empresas.stream()
                .filter(e -> e.getNombre().equalsIgnoreCase(nombre))
                .findFirst()
                .orElse(null);
    }

    public static boolean actualizarCuit(Integer cuitViejo, Integer cuitNuevo) {
        Empresa emp = buscarPorId(cuitViejo);
        if (emp != null) {
            emp.setCuit(cuitNuevo);
            return true;
        }
        return false;
    }

    public static void mostrarEmpresa() {
        empresas.forEach(System.out::println);
    }
}
