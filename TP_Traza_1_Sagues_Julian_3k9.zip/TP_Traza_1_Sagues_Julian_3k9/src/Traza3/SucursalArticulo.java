package Traza3;

import Traza1.Sucursal;

public class SucursalArticulo {
    private String codigoExterno;

    private Sucursal sucursal;
}
